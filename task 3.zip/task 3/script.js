document.addEventListener('DOMContentLoaded', () => {
    const display = document.getElementById('display');
    let currentInput = '';
    let operator = '';
    let firstOperand = '';

    function updateDisplay(value) {
        display.value = value;
    }

    function handleNumber(number) {
        currentInput += number;
        updateDisplay(firstOperand + operator + currentInput);
    }

    function handleOperator(op) {
        if (currentInput === '') return;
        if (firstOperand === '') {
            firstOperand = currentInput;
        } else if (operator) {
            calculate(); // Perform previous calculation
            firstOperand = display.value; // Update first operand to result of previous calculation
        }
        operator = op;
        currentInput = '';
        updateDisplay(firstOperand + operator); // Show the operator in the display
    }

    function calculate() {
        if (firstOperand === '' || currentInput === '' || operator === '') return;
        const a = parseFloat(firstOperand);
        const b = parseFloat(currentInput);
        let result;
        switch (operator) {
            case '+':
                result = a + b;
                break;
            case '-':
                result = a - b;
                break;
            case '*':
                result = a * b;
                break;
            case '/':
                result = a / b;
                break;
            default:
                return;
        }
        updateDisplay(result);
        currentInput = result.toString();
        operator = '';
        firstOperand = '';
    }

    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', () => {
            const id = button.id;
            if (id >= '0' && id <= '9') {
                handleNumber(id);
            } else if (id === 'decimal') {
                if (!currentInput.includes('.')) {
                    handleNumber('.');
                }
            } else if (id === 'clear') {
                currentInput = '';
                operator = '';
                firstOperand = '';
                updateDisplay('');
            } else if (id === 'equals') {
                calculate();
            } else if (['+', '-', '*', '/'].includes(id)) { // Check if id is one of the operator symbols
                handleOperator(id);
            }
        });
    });
});
